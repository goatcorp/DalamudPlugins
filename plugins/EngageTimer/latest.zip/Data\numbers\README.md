﻿# Make your own number textures

Requirements :

- Images must be PNG
- Files must be names from 0.png to 9.png
- Images can be any width
- Images will top-aligned, so I recommend using the same height for all numbers

